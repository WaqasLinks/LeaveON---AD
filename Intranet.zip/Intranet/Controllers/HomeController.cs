﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Intranet.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            //return View();
            //return Redirect("http://OtherSite/Test/Index?id=4");
            //https://localhost:44380/Account/Login?ReturnUrl=%2F

            //return Redirect("https://localhost:44380/");
            //ADUser

            //Response.Redirect("~/Pages/Product.aspx?id=" + id + "&Customize=" + custTotle);

            string ReturnUrlValue = "/";
            string ADUserValue = "hp";
            return Redirect("https://localhost:44380/Account/Login?ReturnUrl="+ ReturnUrlValue + "&ADUser=" + ADUserValue);

        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}